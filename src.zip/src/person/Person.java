package person;
import vehicle.twowheeler.*;

public class Person
{
	String name;
	TwoWheeler twoWheelerObj = new TwoWheeler("Pulsar");
	public Person(String name)
	{
		this.name = name;
		System.out.println("The name of the person is " + name);
	}
	void rideTwoWheeler(String hh)
	{
		System.out.println(name+ " is Riding the "+twoWheelerObj.nameOfTwoWheeler+" and going to " + hh);
	}
//	void eat(Food f)
//	{
//		System.out.println(name +" is eating "+ f.foodItem);
//	}
//	Movie watchingMovie(Laptop laptop)
//	{
//		Movie movieObj = new Movie("Pushpa");
//		return movieObj;
//	}
//	void trading()
//	{
//		System.out.println(name +" is doing share trading");
//	}
//	void fillFeedbackForm()
//	{
//		System.out.println(name+ " filled the feedback form");
//	}
}