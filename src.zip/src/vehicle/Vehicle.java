package vehicle;

public class Vehicle
{	
}