package vehicle.twowheeler;
import vehicle.*;

public class TwoWheeler extends Vehicle
{
	public String nameOfTwoWheeler;
	public TwoWheeler(String nameOfTwoWheeler)
	{
		this.nameOfTwoWheeler = nameOfTwoWheeler;
	}
}
