package javasssignment3;
import person.*;

public class JavaAssignment3 
{
	public static void main(String[] args) 
	{
		Person p1 =  new Person("XYZ");
//		HolidayHome holidayhomeObj = new HolidayHome();
//		holidayhomeObj.setNameHolidayHome("Leh");
//		String nameHolidayHome = holidayhomeObj.getNameHolidayHome();
//		p1.rideTwoWheeler(nameHolidayHome);
//		Food foodObj1 = new Food("Idli");
//		p1.eat(foodObj1);
//		Laptop laptopObj = new Laptop("DELL");
//		//p1.watchingMovie(laptopObj);
//		System.out.println(p1.name +" is watching the movie "+p1.watchingMovie(laptopObj).movieName+" using "+ laptopObj.brandOfLaptop+" laptop");
//		p1.trading();
	}
}